// استيراد نسخة Axios الجاهزة بالإعدادات والتوكن
import API from './axiosInstance';

// دالة لإضافة مصروف جديد
export const addExpense = async (expenseData) => {
  const response = await API.post('/add', expenseData);
  return response.data;
};

// دالة لجلب جميع المصروفات من قاعدة البيانات
export const getExpenses = async () => {
  const response = await API.get('/get');
  return response.data;
};

// دالة لحذف مصروف باستخدام الـ ID
export const deleteExpense = async (id) => {
  const response = await API.delete(`/${id}`);
  return response.data;
};

// دالة لتنزيل ملف Excel الذي يحتوي على جميع المصروفات
export const downloadExpensesExcel = async () => {
  return API.get('/downloadexcel', { responseType: 'blob' });
};
