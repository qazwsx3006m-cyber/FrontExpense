// استيراد مكتبة Axios لإرسال طلبات HTTP إلى الـ Backend
import axios from 'axios';

// إنشاء نسخة مخصصة من Axios تحتوي على إعدادات ثابتة لكل الطلبات
const API = axios.create({
  // رابط الـ API الأساسي (من ملف .env أو localhost في حالة التطوير)
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api/expense',
  // أقصى وقت انتظار للطلب قبل اعتباره فشل
  timeout: 10000,
  headers: {
    // إرسال البيانات بصيغة JSON
    'Content-Type': 'application/json',
  },
});

// إضافة JWT Token تلقائياً في Header قبل إرسال أي Request
API.interceptors.request.use((config) => {
  // قراءة التوكن المخزن بعد تسجيل الدخول
  const token = localStorage.getItem('token');

  // إذا كان التوكن موجوداً يتم إضافته في Authorization
  if (token) {
    config.headers = config.headers || {};
    config.headers.Authorization = `Bearer ${token}`;
  }

  // إرجاع الإعدادات بعد التعديل
  return config;
});

// تصدير نسخة Axios لاستخدامها في باقي ملفات المشروع
export default API;
